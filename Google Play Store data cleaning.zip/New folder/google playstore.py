#!/usr/bin/env python
# coding: utf-8

# In[5]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        
warnings.filterwarnings("ignore")

get_ipython().run_line_magic('matplotlib', 'inline')


# In[3]:


df = pd.read_csv(r'C:\Users\swapn\Downloads\googleplaystore.csv')


# In[6]:


df.head()


# In[7]:


df.tail()


# In[9]:


df.sample(10)


# In[10]:


df.info()


# In[12]:


df.shape


# In[17]:


df[df.duplicated()]


# In[19]:


# duplicate value is available
# 483 rows × 13 columns


# In[22]:


df.describe(include='all').T


# In[26]:


df['Reviews']


# In[28]:


df['Reviews'].shape


# In[25]:


df['Reviews'].dtypes


# In[32]:


# to chake in this df['Reviews'] coloumn text data or categorical data is available or not

df.Reviews.str.isnumeric().sum()


# In[36]:


df['Reviews'].str.isnumeric()


# In[33]:


~df['Reviews'].str.isnumeric()


# In[35]:


# 1 row has text data or categgorical data so we have to remove that
# 3.OM

df[~df['Reviews'].str.isnumeric()]


# In[166]:


df_copy = df.copy()


# In[167]:


df_copy = df_copy.drop(df_copy.index[10472])


# In[168]:


df_copy.shape


# changing data type 

# In[169]:


df['Reviews'].dtypes


# In[170]:


df_copy['Reviews'] = df_copy['Reviews'].astype(int)


# In[171]:


df_copy['Reviews'].dtypes


# In[172]:


df_copy.info()


# In[ ]:





# In[173]:


df_copy['Size']


# In[174]:


df_copy['Size'].unique()


# In[175]:


df_copy['Size'] = df_copy['Size'].str.replace('M','000')


# In[176]:


df_copy['Size']


# In[177]:


df_copy['Size'] = df_copy['Size'].str.replace('k','')


# In[165]:


df_copy['Size'].unique()


# In[178]:


df_copy['Size'] = df_copy['Size'].str.replace('Varies with device',str(np.nan))


# In[179]:


df_copy['Size']


# In[180]:


df_copy['Size'] = df_copy['Size'].astype(float)


# In[181]:


df_copy['Size'].dtype


# In[182]:


df_copy['Size'].isnull().sum()


# In[183]:


df_copy['Size'][2]


# In[184]:


df_copy['Size'][2]*1000


# In[185]:


# to convert decimal numbers

for i in df_copy['Size']:
    if i <10:
        df_copy['Size'] = df_copy['Size'].replace(i,i*1000)


# In[186]:


df_copy['Size'].head()


# In[ ]:





# In[187]:


df_copy['Size'].head()


# In[188]:


df_copy['Size'].unique()


# In[189]:


df_copy['Size'] = df_copy['Size']/1000


# In[190]:


df_copy['Size'].unique()


# In[191]:


df_copy['Size']


# In[192]:


df_copy


# In[193]:


df_copy.columns


# In[194]:


df_copy.head(2)


# In[195]:


df_copy['Installs']


# In[197]:


df_copy['Price'].unique()


# In[204]:


char_to_remove = ['+',',','$']
cols_to_clean = ['Installs', 'Price']
for item in char_to_remove:
    for col in cols_to_clean:
        df_copy[col] = df_copy[col].str.replace(item,'')


# In[205]:


df_copy['Price'].unique()


# In[207]:


df_copy['Installs'].unique()


# In[208]:


df_copy['Installs'] = df_copy['Installs'].astype(int)


# In[209]:


df_copy['Price'] = df_copy['Price'].astype(float)


# In[211]:


df_copy.info()


# In[212]:


df_copy['Last Updated']


# In[214]:


df_copy['Last Updated'] = pd.to_datetime(df_copy['Last Updated'])


# In[215]:


df_copy['Last Updated']


# In[217]:


df_copy.head()


# In[236]:


df_copy["day"]=df_copy['Last Updated'].dt.day


# In[237]:


df_copy["month"]=df_copy['Last Updated'].dt.month


# In[238]:


df_copy["year"]=df_copy['Last Updated'].dt.year


# In[239]:


df_copy.head()


# In[241]:


df_copy.to_csv("google_cleaned1.csv",index=False)


# In[242]:


pd.read_csv("google_cleaned.csv").info()


# In[231]:


pwd


# In[ ]:




